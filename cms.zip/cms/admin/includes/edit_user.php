<?php

if(isset($_GET['u_id']))
{
  $the_user_id = $_GET['u_id'];
}
  $query = "SELECT * FROM users WHERE user_id = $the_user_id";
                    $select_users_by_id = mysqli_query($connection, $query);
                    while($row = mysqli_fetch_assoc($select_users_by_id))
                    {
                         
                        $user_firstname = $row['user_firstname']; 
                        $user_lastname = $row['user_lastname']; 
                        $username = $row['username']; 
                        $user_password= $row['user_password']; 
                        $user_image = $row['user_image']; 
                        $user_email = $row['user_email']; 
                        $user_role = $row['user_role']; 
                        
                       

                    }

if(isset($_POST['update_user']))
{
    $user_firstname = $_POST['user_firstname'];
    $user_lastname= $_POST['user_lastname'];
    $user_role = $_POST['user_role'];
    $user_image = $_FILES['image']['name'];
    $user_image_temp = $_FILES['image']['tmp_name'];
    $username = $_POST['username'];
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    
   // $post_date = date('d-m-y');
   //  $post_comment_count = 4;
    move_uploaded_file($user_image_temp, "../images/$user_image");
    
    
    if(empty($user_image)) {
        
        $query = "SELECT * FROM users WHERE user_id = $the_user_id";
        $select_image = mysqli_query($connection, $query);
        
        while($row = mysqli_fetch_array($select_image))
        {
            $user_image = $row['user_image'];
            
        }
        
        
    }
    
    $query = "UPDATE users SET ";
    $query .= "user_firstname = '{$user_firstname}', ";
    $query .= "user_lastname = '{$user_lastname}' , ";
    $query .= "user_email = '{$user_email}', ";
    $query .= "user_role = '{$user_role}', ";
    $query .= "user_image = '{$user_image}', ";
    $query .= "user_password = '{$user_password}' ";
    $query .= "WHERE user_id = {$the_user_id}";
    
    
    
    $update_user_query = mysqli_query($connection, $query);
    
    confirm($update_user_query);
    
    
}

?>

<form action="" method="post" enctype="multipart/form-data">

   <div class="form-group">
        <label for="title">First Name</label>
        <input type="text" class="form-control" name="user_firstname" value="<?php echo $user_firstname; ?>">
    </div>
    <div class="form-group">
        <label for="post_status">Last Name</label>
        <input type="text" class="form-control" name="user_lastname" value="<?php echo $user_lastname; ?>">
    </div>
    
   
  
    
      <div class="form-group">
        <select name="user_role" id="">
        <?php 
            
           
        
             $query = "SELECT * FROM users";
             $select_users = mysqli_query($connection, $query);
             confirm($select_users);
             while($row = mysqli_fetch_assoc($select_users))
                    {
                        $user_id = $row['user_id']; 
                        $user_role = $row['user_role']; 
                        echo "<option value='$user_id'>{$user_role}</option>";
        
                    }
            
        
        
        ?>
            
      </select>
    
        
        
    </div>
    
    
    
   
    <div class="form-group">
         <img width="100" src="../images/<?php echo $user_image; ?>">
         <input type="file" class="form-control" name="image">
    </div>
  <div class="form-group">
        <label for="post_tags"> UserName</label>
        <input type="text" class="form-control" name="username" value="<?php echo $username; ?>">
    </div>
    <div class="form-group">
        <label for="post_content">Email</label>
        <input type="email" class="form-control" name="user_email" value="<?php echo $user_email; ?>">
    </div>
     <div class="form-group">
        <label for="post_content">Password</label>
        <input type="password" class="form-control" name="user_password" value="<?php echo $user_password; ?>">
    </div>
  
    <div class="form-group">
        <input class="btn btn-primary" type="submit" name="update_user" value="Update User">
    </div> 







